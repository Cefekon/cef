#include <stdio.h> 
#include <string.h>

typedef struct { 
    char name[150]; 
    char surname[150]; 
}
MyStruct;

typedef int (*PredicateFunc)(MyStruct, MyStruct);

void SortArray(MyStruct* arr, size_t arrSize, PredicateFunc predicate) { 
    for (size_t i = 0; i < arrSize; i++) { 
        for (size_t j = 0; j < arrSize - 1 - i; j++) { 
            if (predicate(arr[j], arr[j + 1]) > 0) { 
                MyStruct temp = arr[j]; 
                arr[j] = arr[j + 1]; 
                arr[j + 1] = temp; 
            } 
        } 
    } 
}

int PredicateName(MyStruct s1, MyStruct s2) { 
    return strcmp(s1.name, s2.name); 
}

int main() {
    MyStruct arr[16] = { {"Giniyatullina", "Alina"}, {"Ermolenko", "Maria"}, {"Chernikova", "Anna"}, {"Novikov", "Michail"}, {"Gilyazov", "Artur"},{"Ganeev", "Linar"}, {"Erasov", "Ivan"}, {"Vershinin", "Maxim"}, {"Pogorov", "Ivan"}, {"Potyemin", "Roman"}, {"Martynov", "Ivan"}, {"Smakota", "Egor"}, {"Senchilov", "Konstantin"}, {"Kim", "Konstantin"}, {"Markus", "Kast"}, {"Makovetskaya", "Alexandra"} };

    printf("Before sorting:\n");
    for (int i = 0; i < 16; i++) {
        printf("%s %s\n", arr[i].name, arr[i].surname);
    }

    SortArray(arr, 16, PredicateName);

    printf("\nAfter sorting by name:\n");
    for (int i = 0; i < 16; i++) {
        printf("%s %s\n", arr[i].name, arr[i].surname);
    }

    return 0;
}