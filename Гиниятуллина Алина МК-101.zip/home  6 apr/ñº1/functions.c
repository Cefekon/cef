#include "mass.h"
int* create_array(int size) {
    int* arr;
    arr = (int*)malloc(size * sizeof(int));
    return arr;
}

void fill_array(int size, int* arr) {
    for (int i = 0; i < size; i++) {
        arr[i] = i;
    }
}

void free_array(int* arr) {
    free(arr);
}

void print_array(int size, int* arr) {
    for (int i = 0; i < size; i++) {
        printf(" %d", arr[i]);
    }
    printf("\n");
}

void print_element(int* arr, int index, int size) {
    if (-1 < index < size) {
        printf("%d", arr[index]);
    }
    else {
        printf("This index is not an array index\n");
    }
}

int* get_element(int* arr, int index, int size) {
    if (index >= 0 && index < size) {
        return arr + index;
    }
    else {
        return NULL;
    }
}

int* add_element(int* arr, int* size, int element) {
    (*size)++;
    int* new_arr = (int*)realloc(arr, (*size) * sizeof(int));
    if (new_arr != NULL) {
        new_arr[(*size) - 1] = element;
        return new_arr;
    }
    else {
        return arr;
    }
}
