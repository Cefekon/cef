#pragma once
#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>


int* create_array(int size);
void fill_array(int size, int* arr);
void free_array(int* arr);
void print_array(int size, int* arr);
void print_element(int* arr, int index, int size);
int* get_element(int* arr, int index, int size);
int* add_element(int* arr, int* size, int element);