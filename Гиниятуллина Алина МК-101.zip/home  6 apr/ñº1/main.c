#include "mass.h"

int main() {
	int number_index;
	int index;
	int size;
	size = 10;
	int* arr = create_array(size);
	if (arr == NULL) {
		printf("Memory allocation failed\n");
		return 0;
	}
	fill_array(size, arr);
	print_array(size, arr);
	printf("Enter index: ");
	scanf_s("%d", &index);

	int* result = get_element(arr, index, size);
	if (result != NULL) {
		printf("%d\n", *result);
	}
	else {
		printf("Invalid index\n");
	}

	int new_element;

	for (int i = 0; i < 16; i++) {
		printf("Enter the new element: ");
		scanf_s("%d", &new_element);
		arr = add_element(arr, &size, new_element);
		print_array(size, arr);
	}

	free_array(arr);
	return 0;
}
