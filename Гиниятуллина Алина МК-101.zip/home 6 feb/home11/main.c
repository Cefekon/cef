#include <stdio.h>
#include <stdlib.h>

int main() {
    int initialCapacity = 5;
    int* arr = (int*)malloc(sizeof(int) * initialCapacity);
    int* curr = arr;

    for (int i = 0; i < initialCapacity; i++) {
        *curr = i * 10;
        curr++;
    }

    
    for (int i = 0; i < initialCapacity; i++) {
        printf("%d\n", *(arr + i));
    }

    
    int newCapacity = 10;
    int* temp = (int*)realloc(arr, sizeof(int) * newCapacity);
    if (temp != NULL) {
        arr = temp;
        curr = arr + initialCapacity;

        for (int i = initialCapacity; i < newCapacity; i++) {
            *curr = i * 10;
            curr++;
        }

        
        for (int i = 0; i < newCapacity; i++) {
            printf("%d\n", *(arr + i));
        }

        free(arr);
    }
    else {
        
        printf("Error reallocating memory\n");
    }

    return 0;
}
